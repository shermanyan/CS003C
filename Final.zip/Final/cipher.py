class Cipher:

    _key = None

    def __init__(self, key=None, message=None):
        self._message = message.upper()
        self._key = key.upper()

        self._key = self._genKey(self._key)

    ##
    # generates the key from the keyword
    # @param the key
    # @return the new key
    #
    def _genKey(self, message):
        newKey = ""
        for char in range(len(message)):
            if message[char] not in newKey:
                newKey += message[char]

        for i in range(26):
            if chr(90 - i) not in newKey:
                newKey += chr(90 - i)

        return newKey

    ##
    # encrypts the line with given key
    # @param line, key
    # @return the encoded line
    #
    def encode(self):
        encoded = ""

        for char in self._message:
            if str(char).isalpha():
                encoded += self._key[(ord(char) - 65)]
            elif str(char).isspace():
                encoded += " "
        return encoded

    ##
    # decrypts the line with given key
    # @param line, key
    # @return the decoded key
    #
    def decode(self):
        decoded = ""
        for char in self._message:
            if char in self._key:
                decoded += chr(65 + self._key.index(char))
            elif str(char).isspace():
                decoded += " "
        return decoded
