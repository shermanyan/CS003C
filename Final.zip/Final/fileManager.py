

class OpenFile:

    def __init__(self):
        self._file = None

    def openFile(self, fileType, fileReadType):

        filename = str(input(fileType + " file name: "))
        try:
            file = open(filename, fileReadType)
            self._file = file
        except IOError:
            print("ERROR: File \"" + filename + "\" opening error, try again.")
            return self.openFile(fileType, fileReadType)

    def getFile(self):
        return self._file

    def getFileData(self):
        lineData = []
        data = ""
        for line in self._file:
            lineData.append(line.strip())

        for i in lineData:
            data += str(i) + ' '

        return data[:-1]

    def closeFile(self):
        self._file.close()

