from io import SEEK_CUR
from fileManager import OpenFile

class ImageProcessing:

    def __init__(self):
        self._imageFile = None
        self._startPixel = None
        self._numSkipPixels = None
        self._msgLength = None

        self._fileSize = None
        self._start = None
        self._width = None
        self._height = None
        self._scanlineSize = None
        self._padding = None

    def getImage(self):
        try:
            fileManager = OpenFile()
            fileManager.openFile("Image", 'rb+')
            self._imageFile = fileManager.getFile()
            self._gatherImageInfo()
            self._checkImage()
        except TypeError as typeError:
            print("Error:", typeError)
            return self.getImage()

    def _checkImage(self):

        if self._fileSize != (self._start + (self._scanlineSize + self._padding) * self._height):
            raise TypeError("Not a 24-bit true color image file.")

    def _gatherImageInfo(self):
        self._fileSize = self._readInt(2)
        self._start = self._readInt(10)
        self._width = self._readInt(18)
        self._height = self._readInt(22)
        self._scanlineSize = self._width * 3
        self._padding = self._getPadding()

    def setStartStopStep(self, start=0, stop=0, step=0):
        self._startPixel = (self._start - 1) + (int(start) * 3)
        self._numSkipPixels = step
        self._msgLength = stop

    def getImageMessage(self):
        message = ""

        self._imageFile.seek(self._startPixel)
        currChar = self._imageFile.read(1)
        self._imageFile.seek(2, SEEK_CUR)

        while currChar and len(message) < self._msgLength:
            message += chr(*currChar)

            seekToNext = 0
            while seekToNext < self._numSkipPixels * 3:
                self._imageFile.seek(1, SEEK_CUR)
                if (self._imageFile.tell() - self._start) % (self._width * 3 + self._padding) < self._width * 3:
                    seekToNext += 1

            currChar = self._imageFile.read(1)
            self._imageFile.seek(2, SEEK_CUR)

        return message

    def writeImageMessage(self, message):

        characters = []

        for i in range(len(message)):                               # convert string to char list
            characters.append(message[i])

        self._imageFile.seek(self._startPixel)

        for i in range(len(characters)):
            self._imageFile.write(bytes([ord(characters[i])]))                        # write the byte
            self._imageFile.seek(2, SEEK_CUR)

            seekToNext = 0
            while seekToNext < self._numSkipPixels:
                self._imageFile.seek(3, SEEK_CUR)
                if (self._imageFile.tell() - self._start) % (self._width*3 + self._padding) < self._width * 3:
                    seekToNext += 1

    def _readInt(self, offset):
        # Move the file pointer to the given byte within the file.
        self._imageFile.seek(offset)
        # Read the 4 individual bytes and build an integer. theBytes = imgFile.read(4)
        theBytes = self._imageFile.read(4)
        result = 0
        base = 1
        for i in range(4):
            result = result + theBytes[i] * base
            base = base * 256

        return result

    def _getPadding(self):
        if self._scanlineSize % 4 == 0:
            padding = 0
        else:
            padding = 4 - self._scanlineSize % 4
        return padding

    def closeFile(self):
        self._imageFile.close()
