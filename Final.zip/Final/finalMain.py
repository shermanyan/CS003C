"""
Final Project
"""

from cipher import Cipher
from imageProcessor import ImageProcessing
from fileManager import OpenFile


def main():
    try:
        option = (input("Encrypt(E) or Decrypt(D)? ")).upper()
        if not (option == 'D' or option == 'E'):
            raise ValueError("Invalid type, try again.")
    except ValueError as error:
        print("ERROR:", str(error))
        return main()

    imageProcessor = ImageProcessing()
    imageProcessor.getImage()
    key, code, msgLength = getKey()
    imageProcessor.setStartStopStep(code[0], msgLength, code[1])

    if option == 'E':
        fileManager = OpenFile()
        fileManager.openFile("Message", 'r')
        message = fileManager.getFileData()
        fileManager.closeFile()

        cryption = Cipher(key, message)
        message = cryption.encode()
        imageProcessor.writeImageMessage(message)
        print("Message Encrypted\n" +
              "Key: " + key + str(len(message)) + "\n" +
              "Code 1: " + str(code[0]) + "\n" +
              "Code 2: " + str(code[1]))

    else:
        codedMessage = imageProcessor.getImageMessage()
        cryption = Cipher(key, codedMessage)
        decodedMessage = cryption.decode()
        print("Decoded Message:", decodedMessage)

    imageProcessor.closeFile()
    print("Thank You")


def getKey(name=None):
    code = []
    msgLen = "0"
    try:
        while not name:
            name = input("Enter key: ")
            for i in range(len(name)):
                if not name[i].isalnum():
                    raise NameError("Invalid key format")
        while not len(code) == 2:
            code.append(int(input("Code " + str(len(code) + 1) + ": ")))

        for i in name:
            if i.isnumeric():
                msgLen += i
                name = name.replace(i, "")

        return name, code, int(msgLen)

    except NameError as error:
        print("ERROR:", str(error))
        return getKey()
    except ValueError:
        print("ERROR: Code must be an integer")
        return getKey(name)


main()
